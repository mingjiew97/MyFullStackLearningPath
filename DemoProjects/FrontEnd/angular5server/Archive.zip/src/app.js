import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import mongoose from 'mongoose';

import {getHeroes} from './controllers/heroes.controller';
import {getProducts, getProduct, postProducts, putProducts, deleteProducts} from './controllers/products.controller';
import {postFBLogin, postLogin, postRegister} from "./controllers/users.controller";

// Connect to Mongodb
mongoose.Promise = global.Promise;
const conn = mongoose.connect("mongodb://localhost:27017/mercury");
conn.then(() => {
  console.log('mongodb connected!');
}, (err) => {
  console.log('mongodb connection failed.');
});

const app = express();

app.use(cors());
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());

app.post('/login', postLogin);
app.post('/fblogin', postFBLogin);
app.post('/register', postRegister);

app.get('/heroes', getHeroes);

app.get('/products', getProducts);
app.get('/products/:name', getProduct);
app.post('/products', postProducts);
app.put('/products/:name', putProducts);
app.delete('/products/:name', deleteProducts);

// error handling
app.use((err, req, res, next) => {
  res.json({
    success: false,
    err: err
  })
});

app.listen(process.env.port || 3000);
console.log("server started");

export {app};