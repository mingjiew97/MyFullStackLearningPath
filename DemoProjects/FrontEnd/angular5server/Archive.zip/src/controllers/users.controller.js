import User from '../models/users.model';
import bcrypt from 'bcrypt';

export function postLogin(req, res, next) {
  const {email, password} = req.body;
  User.findOne({email}, (err, user) => {
    if(err) return next(err);
    if(!user) return next('email does not exist.');
    if(user.password === undefined) return next('try third party login.');
    bcrypt.compare(password, user.password, (err, result) => {
      if(result) {
        res.json({
          success: true,
          user
        });
      } else {
        return next('password is not correct.')
      }
    });
  });
}

export function postRegister(req, res, next) {
  const user = new User(req.body);
  bcrypt.hash(req.body.password, 10, (err, hash) => {
    if(err) return next(err);
    user.password = hash;
    user.save((err) => {
      if(err) return next('Register failed.');
      res.json({
        success: true
      });
    });
  });
}

export function postFBLogin(req, res, next) {
  const fbUser = req.body;
  User.findOne({email: fbUser.email}, (err, user) => {
    if(err) return next(err);
    if(!user) { //register
      const user = new User({
        name: `${fbUser.firstName} ${fbUser.lastName}`,
        email: fbUser.email,
        fbProvider: {
          id: fbUser.id,
          authToken: fbUser.authToken
        }
      });
      user.save((err) => {
        if(err) return next(err);
        res.json({
          success: true,
          user
        });
      });
    } else {
      if(user.fbProvider.id === fbUser.id) {
        res.json({
          success: true,
          user
        });
      } else{
        return next('your information is not correct.');
      }
    }
  });
}