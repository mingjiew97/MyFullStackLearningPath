export let products = [
  { name: 'iPhone', brand: 'Apple', price: 100, stock: 22, image: 'https://s3.amazonaws.com/msi-tech/iphone.jpg' },
  { name: 'iPhone3G', brand: 'Apple', price: 200, stock: 33, image: 'https://s3.amazonaws.com/msi-tech/iphone3G.jpg' },
  { name: 'iPhone3GS', brand: 'Apple', price: 300, stock: 11, image: 'https://s3.amazonaws.com/msi-tech/iphone3GS.jpg' },
  { name: 'iPhone4', brand: 'Apple', price: 400, stock: 22, image: 'https://s3.amazonaws.com/msi-tech/iphone4.jpg' },
  { name: 'iPhone4S', brand: 'Apple', price: 500, stock: 33, image: 'https://s3.amazonaws.com/msi-tech/iphone4S.jpg' },
  { name: 'iPhone5', brand: 'Apple', price: 600, stock: 11, image: 'https://s3.amazonaws.com/msi-tech/iphone5.jpeg' },
  { name: 'iPhone5C', brand: 'Apple', price: 700, stock: 222, image: 'https://s3.amazonaws.com/msi-tech/iphone5c.png' },
  { name: 'iPhone5S', brand: 'Apple', price: 800, stock: 333, image: 'https://s3.amazonaws.com/msi-tech/iphone5s.jpg' },
  { name: 'iPhone6', brand: 'Apple', price: 900, stock: 111, image: 'https://s3.amazonaws.com/msi-tech/iphone6.jpg' },
];